import mysql.connector as c

# def populate_database():

