# CSE202-Online-Retail-Store
## Precursors:
Run "pip install mysql-connector-python" in Terminal.     // to install mysql connector for python
